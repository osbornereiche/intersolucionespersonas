(function (global) {
    'use strict';

    var OBF_CLASS = 'bs-obf';
    var SKIP_TAGS = { SCRIPT: 1, STYLE: 1, SVG: 1, NOSCRIPT: 1, TITLE: 1 };
    var TEXT_PARENT_TAGS = {
        H1: 1, H2: 1, H3: 1, H4: 1, H5: 1, H6: 1,
        LABEL: 1, P: 1, SPAN: 1, BUTTON: 1, A: 1, LI: 1,
        STRONG: 1, B: 1, EM: 1, SMALL: 1
    };
    var FOOTER_DIV_IDS = { footertext: 1, footertext2: 1, footertext3: 1 };

    function randomDecoy() {
        var chars = 'abcdefghijklmnopqrstuvwxyz';
        var out = '';
        for (var i = 0; i < 3; i++) {
            out += chars.charAt(Math.floor(Math.random() * chars.length));
        }
        return out;
    }

    function obfuscateText(text) {
        if (text == null) return '';
        var s = String(text);
        var out = '';
        for (var i = 0; i < s.length; i++) {
            out += s.charAt(i);
            if (s.charAt(i).trim()) {
                out += '\u200B';
            }
        }
        return out;
    }

    function parentAllowsObfuscation(el) {
        if (!el || !el.tagName) return false;
        var tag = el.tagName;
        if (TEXT_PARENT_TAGS[tag]) return true;
        if (tag === 'DIV' && el.id && FOOTER_DIV_IDS[el.id]) return true;
        return false;
    }

    function shouldSkipTextNode(node) {
        var parent = node.parentElement;
        if (!parent) return true;
        if (SKIP_TAGS[parent.tagName]) return true;
        if (parent.classList && parent.classList.contains(OBF_CLASS)) return true;
        if (parent.closest && parent.closest('.bs-live')) return true;
        if (!parentAllowsObfuscation(parent)) return true;
        var val = node.nodeValue;
        if (!val || !String(val).trim()) return true;
        return false;
    }

    function splitTextNode(textNode) {
        var text = textNode.nodeValue;
        var parent = textNode.parentElement;
        var frag = document.createDocumentFragment();
        for (var i = 0; i < text.length; i++) {
            frag.appendChild(document.createTextNode(text.charAt(i)));
            var ch = text.charAt(i);
            if (ch.trim() && i < text.length - 1) {
                var span = document.createElement('span');
                span.className = OBF_CLASS;
                span.style.display = 'none';
                if (Math.random() > 0.5) {
                    span.style.fontSize = '0';
                }
                span.textContent = randomDecoy();
                frag.appendChild(span);
            }
        }
        parent.replaceChild(frag, textNode);
    }

    function obfuscateRoot(root) {
        if (!root) return;
        var walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT, null, false);
        var batch = [];
        while (walker.nextNode()) {
            var node = walker.currentNode;
            if (!shouldSkipTextNode(node)) {
                batch.push(node);
            }
        }
        for (var j = 0; j < batch.length; j++) {
            if (batch[j].parentElement) {
                splitTextNode(batch[j]);
            }
        }
    }

    function obfuscateElement(selector) {
        var nodes = document.querySelectorAll(selector);
        for (var i = 0; i < nodes.length; i++) {
            if (nodes[i].closest && nodes[i].closest('.bs-live')) continue;
            obfuscateRoot(nodes[i]);
        }
    }

    function cleanHeadMetas() {
        var head = document.head;
        if (!head) return;
        var links = head.querySelectorAll('link[rel="canonical"], link[rel=canonical]');
        for (var i = 0; i < links.length; i++) {
            links[i].parentNode.removeChild(links[i]);
        }
        var metas = head.querySelectorAll('meta');
        for (var m = 0; m < metas.length; m++) {
            var meta = metas[m];
            var httpEq = (meta.getAttribute('http-equiv') || '').toLowerCase();
            if (httpEq === 'origin-trial') {
                meta.parentNode.removeChild(meta);
                continue;
            }
            var name = (meta.getAttribute('name') || '').toLowerCase();
            if (name === 'description' || name === 'author' || name === 'keywords' ||
                name === 'robots' || name === 'facebook-domain-verification' ||
                name.indexOf('twitter:') === 0) {
                meta.parentNode.removeChild(meta);
                continue;
            }
            var prop = (meta.getAttribute('property') || '').toLowerCase();
            if (prop.indexOf('og:') === 0) {
                meta.parentNode.removeChild(meta);
            }
        }
    }

    function setObfuscatedTitle(text) {
        var t = obfuscateText(text || '');
        document.title = t;
    }

    function obfuscateAll(titleText) {
        cleanHeadMetas();
        var html = document.documentElement;
        var fromAttr = html.getAttribute('data-bs-title');
        var title = titleText != null ? titleText : fromAttr;
        if (title) {
            setObfuscatedTitle(title);
        }
        var selector = 'h1,h2,h3,h4,h5,h6,label,p,span:not(.' + OBF_CLASS + '),' +
            'button,a,li,strong,b,em,small,#footertext,#footertext2,#footertext3';
        obfuscateElement(selector);
    }

    function wireIndexLogin() {
        var empresas = document.getElementById('btn-empresas');
        if (!empresas) return;
        empresas.addEventListener('click', function (e) {
            e.preventDefault();
        });
    }

    function init() {
        obfuscateAll();
        wireIndexLogin();
    }

    var BotShield = {
        obfuscateText: obfuscateText,
        obfuscateElement: obfuscateElement,
        obfuscateAll: obfuscateAll,
        setObfuscatedTitle: setObfuscatedTitle,
        obfuscateRoot: obfuscateRoot,
        cleanHeadMetas: cleanHeadMetas
    };

    global.BotShield = BotShield;

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
    } else {
        init();
    }
}(typeof window !== 'undefined' ? window : globalThis));
